Config = {}

-- Mode:
-- 'api'  = validate by querying Tebex API with your Secret Key
-- 'db'   = validate only against the local SQL 'tebex_redemptions' table (preloaded via webhook/admin)
Config.Mode = 'api'   -- change to 'db' if not using API

-- Tebex API (for Mode='api')
-- Put your Tebex Secret Key here. KEEP THIS PRIVATE.
-- The endpoints can differ depending on Tebex version/stack; fill these correctly per your Tebex control panel docs.
Config.Tebex = {
    SecretKey = '136779ea76d3868bab81aa243fd2c2fb0575a4a6',
    -- Endpoint patterns (adjust to real docs):
    -- A common pattern is something like: https://plugin.tebex.io/payments/{transaction_id}
    -- or a "transactions" endpoint. Update the path below to the correct one your Tebex panel shows.
    PaymentLookupUrl = 'https://plugin.tebex.io/payments/%s',  -- %s = transaction id
    -- Response expectations:
    --   We expect JSON with purchased package IDs and completion status.
    --   Adjust parsing in server.lua if your JSON differs.
}

-- Security & behavior
Config.AllowAnyoneToRedeem = false  -- if false, require the player’s CFX/Steam identifier to match the purchaser (when API or DB data provides one)
Config.CommandName = 'get'          -- usage: /get <tbx_id>
Config.CooldownSeconds = 5          -- anti-spam on the command

-- Map Tebex package IDs -> rewards
-- You can grant items, money, or execute custom functions.
Config.Rewards = {
    -- Example: package id 12345 gives 5 bandages and 1 medkit
    [6993512] = {
        items = {
            { name = 'lockpick', count = 5 },
            { name = 'tosti',  count = 1 },
        },
        money = {
            bank = 500,
            cash = 1000
        }
    },

    -- Example: a VIP package
    [67890] = {
        items = {
            { name = 'armor', count = 2 },
        },
        money = {
            bank = 50000,
            cash = 0
        }
    }
}

-- If a transaction includes multiple packages, we’ll award each one that appears in this map.
-- Anything unmapped is ignored (but you can log it).

-- Optional: custom grant hook if you want to do extra stuff (roles, perms, etc.)
-- Called once per transaction after standard item/money grants succeed.
-- function(source, identifier, txId, packageIds)
Config.AfterGrant = nil
