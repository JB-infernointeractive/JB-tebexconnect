local QBCore = exports['qb-core']:GetCoreObject()
local lastUse = {}

local function GetPlayerIdentifier(src)
    -- Prefer cfx license, fallback to steam etc.
    -- Adjust to your server’s identity policy.
    local ids = GetPlayerIdentifiers(src)
    local license, steam
    for _, id in ipairs(ids) do
        if id:find('license:') == 1 then license = id
        elseif id:find('steam:') == 1 then steam = id end
    end
    return license or steam or ids[1]
end

local function CooldownOk(src)
    local now = os.time()
    if not lastUse[src] or now - lastUse[src] >= Config.CooldownSeconds then
        lastUse[src] = now
        return true
    end
    return false
end

-- === Tebex API (Mode: 'api') ===
local function TebexFetchTransaction(txId, cb)
    local url = string.format(Config.Tebex.PaymentLookupUrl, txId)
    PerformHttpRequest(url, function(status, body, headers)
        if status ~= 200 or not body or body == '' then
            cb(nil, ('HTTP %s'):format(status))
            return
        end
        local ok, data = pcall(json.decode, body)
        if not ok or type(data) ~= 'table' then
            cb(nil, 'Bad JSON from Tebex')
            return
        end
        cb(data, nil)
    end, 'GET', '', { ['X-Tebex-Secret'] = Config.Tebex.SecretKey })
end

-- Extract useful fields from Tebex JSON.
-- Adjust this to match your Tebex response schema.
local function ParseTebexPayment(paymentJson)
    -- Expecting something like:
    -- {
    --   "status": "Complete",
    --   "transaction_id": "TBX-XXXX",
    --   "player": { "id": "...", "name": "...", "identifiers": ["license:xxxxx","steam:xxxxx"] },
    --   "packages": [{ "id": 12345 }, { "id": 67890 }]
    -- }
    local status = (paymentJson.status or ''):lower()
    local complete = (status == 'complete' or status == 'completed' or status == 'paid')
    local txId = paymentJson.transaction_id or paymentJson.id or ''
    local packageIds = {}

    if type(paymentJson.packages) == 'table' then
        for _, p in ipairs(paymentJson.packages) do
            if p.id then table.insert(packageIds, tonumber(p.id) or p.id) end
        end
    end

    local purchaserIdentifier
    if paymentJson.player and type(paymentJson.player.identifiers) == 'table' then
        for _, id in ipairs(paymentJson.player.identifiers) do
            if type(id) == 'string' and id:find('license:') == 1 then
                purchaserIdentifier = id
                break
            end
        end
        -- fallback to first identifier if no license
        purchaserIdentifier = purchaserIdentifier or paymentJson.player.identifiers[1]
    end

    return {
        complete = complete,
        txId = txId,
        packageIds = packageIds,
        purchaserIdentifier = purchaserIdentifier
    }
end

local function MarkRedeemed(txId, claimerIdentifier, packageIds, itemsSnapshot)
    MySQL.insert.await([[
        INSERT INTO tebex_redemptions (tx_id, purchaser_identifier, package_ids, items_json, status, claimed_by_identifier, claimed_at)
        VALUES (?, NULL, ?, ?, 'redeemed', ?, NOW())
        ON DUPLICATE KEY UPDATE
          status = 'redeemed',
          claimed_by_identifier = VALUES(claimed_by_identifier),
          claimed_at = VALUES(claimed_at),
          package_ids = VALUES(package_ids),
          items_json = VALUES(items_json)
    ]], {
        txId,
        table.concat(packageIds, ','),
        itemsSnapshot and json.encode(itemsSnapshot) or nil,
        claimerIdentifier
    })
end

local function AlreadyRedeemed(txId)
    local row = MySQL.single.await('SELECT status FROM tebex_redemptions WHERE tx_id = ?', { txId })
    return row and row.status == 'redeemed' or false
end

local function RecordPendingIfNew(txId, purchaserIdentifier, packageIds)
    -- keep a record locally; helpful for support/dup checks
    MySQL.insert.await([[
        INSERT IGNORE INTO tebex_redemptions (tx_id, purchaser_identifier, package_ids, status)
        VALUES (?, ?, ?, 'pending')
    ]], { txId, purchaserIdentifier, #packageIds > 0 and table.concat(packageIds, ',') or nil })
end

local function GiveRewards(src, packageIds)
    local xPlayer = QBCore.Functions.GetPlayer(src)
    if not xPlayer then return false, 'Player not found' end

    local granted = { items = {}, money = {cash = 0, bank = 0} }

    for _, pkg in ipairs(packageIds) do
        local reward = Config.Rewards[tonumber(pkg)] or Config.Rewards[pkg]
        if reward then
            if reward.items then
                for _, item in ipairs(reward.items) do
                    xPlayer.Functions.AddItem(item.name, item.count or 1)
                    -- if using qb-inventory with metadata, extend here as needed
                    table.insert(granted.items, { name = item.name, count = item.count or 1 })
                    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[item.name], 'add') -- optional
                end
            end
            if reward.money then
                if (reward.money.cash or 0) > 0 then
                    xPlayer.Functions.AddMoney('cash', reward.money.cash)
                    granted.money.cash = granted.money.cash + reward.money.cash
                end
                if (reward.money.bank or 0) > 0 then
                    xPlayer.Functions.AddMoney('bank', reward.money.bank)
                    granted.money.bank = granted.money.bank + reward.money.bank
                end
            end
        else
            print(('[TebexRedeem] No reward mapping for package "%s"'):format(tostring(pkg)))
        end
    end
    return true, granted
end

local function HandleRedemption(src, txId)
    if AlreadyRedeemed(txId) then
        TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'This transaction was already redeemed.'} })
        return
    end

    local claimerId = GetPlayerIdentifier(src)

    if Config.Mode == 'api' then
        TebexFetchTransaction(txId, function(jsonData, err)
            if err or not jsonData then
                TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'Could not validate transaction. Try again later.'} })
                print('[TebexRedeem] API error for '..txId..': '..tostring(err))
                return
            end

            local parsed = ParseTebexPayment(jsonData)
            if not parsed.complete then
                TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'That purchase isn’t marked complete yet.'} })
                RecordPendingIfNew(txId, parsed.purchaserIdentifier, parsed.packageIds)
                return
            end

            -- Optional ownership check
            if not Config.AllowAnyoneToRedeem and parsed.purchaserIdentifier and parsed.purchaserIdentifier ~= claimerId then
                TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'This purchase belongs to another account.'} })
                return
            end

            local ok, grantedOrErr = GiveRewards(src, parsed.packageIds)
            if not ok then
                TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'Could not grant rewards: '..tostring(grantedOrErr)} })
                return
            end

            MarkRedeemed(txId, claimerId, parsed.packageIds, grantedOrErr)
            TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'Success! Your items have been delivered.'} })

            if type(Config.AfterGrant) == 'function' then
                pcall(Config.AfterGrant, src, claimerId, txId, parsed.packageIds)
            end
        end)

    else
        -- Mode 'db': only allow redeeming known pending rows
        local row = MySQL.single.await('SELECT * FROM tebex_redemptions WHERE tx_id = ?', { txId })
        if not row or row.status ~= 'pending' then
            TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'Transaction not found or not pending.'} })
            return
        end

        -- Optional ownership check
        if not Config.AllowAnyoneToRedeem and row.purchaser_identifier and row.purchaser_identifier ~= claimerId then
            TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'This purchase belongs to another account.'} })
            return
        end

        local packageIds = {}
        if row.package_ids and row.package_ids ~= '' then
            for id in string.gmatch(row.package_ids, '([^,]+)') do
                table.insert(packageIds, tonumber(id) or id)
            end
        else
            -- if you preload items_json only, you can infer here, or store a synthetic package id
            TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'No package mapping on file for this transaction.'} })
            return
        end

        local ok, grantedOrErr = GiveRewards(src, packageIds)
        if not ok then
            TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'Could not grant rewards: '..tostring(grantedOrErr)} })
            return
        end

        MarkRedeemed(txId, claimerId, packageIds, grantedOrErr)
        TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'Success! Your items have been delivered.'} })

        if type(Config.AfterGrant) == 'function' then
            pcall(Config.AfterGrant, src, claimerId, txId, packageIds)
        end
    end
end

RegisterCommand(Config.CommandName, function(source, args)
    local src = source
    if src <= 0 then
        print('[TebexRedeem] Command is player-only.')
        return
    end
    if not CooldownOk(src) then
        TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', 'Slow down...'} })
        return
    end

    local txId = args[1]
    if not txId or txId == '' then
        TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', ('Usage: /%s <tbx_id>'):format(Config.CommandName)} })
        return
    end

    CreateThread(function()
        HandleRedemption(src, txId)
    end)
end)

-- /tebex:addpending <tx> <identifier> <pkgId1,pkgId2>
-- Example: /tebex:addpending TBX-12345 license:abcd1234 12345,67890
RegisterCommand('tebex:addpending', function(source, args)
    local src = source

    if src ~= 0 then
        local xPlayer = QBCore.Functions.GetPlayer(src)
        if not xPlayer then return end
        -- Only allow admins
        if not IsPlayerAceAllowed(src, "tebex.addpending") and not xPlayer.PlayerData.job.isboss then
            TriggerClientEvent('chat:addMessage', src, { args = { 'Tebex', 'You do not have permission to use this.' } })
            return
        end
    end

    local txId       = args[1]
    local identifier = args[2]
    local pkgList    = args[3]

    if not txId or not identifier or not pkgList then
        if src > 0 then
            TriggerClientEvent('chat:addMessage', src, { args = { 'Tebex', 'Usage: /tebex:addpending <tx> <identifier> <pkgId1,pkgId2>' } })
        else
            print("Usage: /tebex:addpending <tx> <identifier> <pkgId1,pkgId2>")
        end
        return
    end

    -- sanitize package IDs into comma string
    local pkgIds = {}
    for id in string.gmatch(pkgList, '([^,]+)') do
        table.insert(pkgIds, tonumber(id) or id)
    end
    local pkgStr = table.concat(pkgIds, ",")

    -- Insert or update
    MySQL.insert.await([[
        INSERT INTO tebex_redemptions (tx_id, purchaser_identifier, package_ids, status)
        VALUES (?, ?, ?, 'pending')
        ON DUPLICATE KEY UPDATE
            purchaser_identifier = VALUES(purchaser_identifier),
            package_ids = VALUES(package_ids),
            status = 'pending'
    ]], { txId, identifier, pkgStr })

    if src > 0 then
        TriggerClientEvent('chat:addMessage', src, { args = { 'Tebex', ('Pending TX %s added for %s with packages %s'):format(txId, identifier, pkgStr) } })
    else
        print(('[Tebex] Added pending TX %s for %s (%s)'):format(txId, identifier, pkgStr))
    end
end, true)

-- Console-only command for Tebex:
-- Usage (no slash in Tebex!): tbx_addpending {transaction} {hexid} {packageId}
-- Example (manual console): tbx_addpending TBX-123 steam:110000112345678 67890
RegisterCommand('tbx_addpending', function(source, args)
    -- Only allow from console or ACE-protected sources
    if source ~= 0 and not IsPlayerAceAllowed(source, "tebex.exec") then
        if source > 0 then
            TriggerClientEvent('chat:addMessage', source, { args = {'Tebex', 'No permission.'} })
        end
        return
    end

    local txId       = args[1]
    local identifier = args[2]
    local pkgId      = args[3]

    if not txId or not identifier or not pkgId then
        if source == 0 then
            print("Usage: tbx_addpending <tx> <identifier> <packageId[,packageId2,...]>")
        else
            TriggerClientEvent('chat:addMessage', source, { args = {'Tebex', 'Usage: tbx_addpending <tx> <identifier> <packageId[,packageId2,...]>'} })
        end
        return
    end

    -- support multiple package IDs
    local pkgIds = {}
    for id in string.gmatch(pkgId, '([^,]+)') do
        table.insert(pkgIds, tonumber(id) or id)
    end
    local pkgStr = table.concat(pkgIds, ",")

    MySQL.insert.await([[
        INSERT INTO tebex_redemptions (tx_id, purchaser_identifier, package_ids, status)
        VALUES (?, ?, ?, 'pending')
        ON DUPLICATE KEY UPDATE
            purchaser_identifier = VALUES(purchaser_identifier),
            package_ids = VALUES(package_ids),
            status = 'pending'
    ]], { txId, identifier, pkgStr })

    print(('[Tebex] Queued pending TX %s for %s with packages %s'):format(txId, identifier, pkgStr))
end)

AddEventHandler('QBCore:Server:PlayerLoaded', function(player)
    local src = player.PlayerData.source
    local ids = GetPlayerIdentifiers(src)
    local license
    for _, id in ipairs(ids) do
        if id:find('license:') == 1 then license = id break end
    end
    local identifier = license or ids[1]

    local rows = MySQL.query.await('SELECT tx_id, package_ids FROM tebex_redemptions WHERE status="pending" AND purchaser_identifier = ?', { identifier })
    if not rows or #rows == 0 then return end

    for _, row in ipairs(rows) do
        local packageIds = {}
        for id in string.gmatch(row.package_ids or '', '([^,]+)') do
            table.insert(packageIds, tonumber(id) or id)
        end

        local ok, grantedOrErr = GiveRewards(src, packageIds) -- uses your existing function
        if ok then
            MySQL.update.await('UPDATE tebex_redemptions SET status="redeemed", claimed_by_identifier=?, claimed_at=NOW() WHERE tx_id=?', { identifier, row.tx_id })
            TriggerClientEvent('chat:addMessage', src, { args = {'Tebex', ('Your Tebex purchase %s has been delivered.'):format(row.tx_id)} })
        else
            print(('[Tebex] Auto-deliver failed for %s: %s'):format(row.tx_id, tostring(grantedOrErr)))
        end
    end
end)