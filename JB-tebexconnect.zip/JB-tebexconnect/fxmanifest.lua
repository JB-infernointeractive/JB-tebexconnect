fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'Tebex Redemption (/get <tx>) for QBCore'
version '1.0.0'

server_scripts {
  '@oxmysql/lib/MySQL.lua',   -- or ghmattimysql if you prefer; adjust code accordingly
  'config.lua',
  'server.lua'
}


shared_scripts {
  '@qb-core/shared/locale.lua',
  'config.lua'
}
