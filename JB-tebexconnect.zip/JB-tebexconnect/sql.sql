-- one row per Tebex transaction we’ve seen or redeemed
CREATE TABLE IF NOT EXISTS tebex_redemptions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tx_id VARCHAR(64) NOT NULL UNIQUE,                 -- the Tebex transaction id (what player types)
  purchaser_identifier VARCHAR(64) DEFAULT NULL,     -- cfx/steam license if known
  package_ids VARCHAR(255) DEFAULT NULL,             -- comma-separated package ids (e.g., 12345,67890)
  items_json TEXT DEFAULT NULL,                      -- optional: snapshot of items that were/should be given
  status ENUM('pending','redeemed','invalid') NOT NULL DEFAULT 'pending',
  claimed_by_identifier VARCHAR(64) DEFAULT NULL,
  claimed_at TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- optional index for lookup by identifier
CREATE INDEX idx_tebex_redemptions_buyer ON tebex_redemptions (purchaser_identifier);
